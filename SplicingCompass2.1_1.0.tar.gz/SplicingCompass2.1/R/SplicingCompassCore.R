####                                       ####<< class definition  >>####
setClass("SplicingCompass",
         representation(
                        data="list"
                        )
         )
####                                       ####<< generics  >>####
setMethod("show", signature="SplicingCompass",
          function(object) {
            cat("SplicingCompass Object\n")
            if (is.null(object@data[["expInf"]])){
              cat(paste("Experiment not set\n"))
            } else {
              cat(paste("Experiment:",getDescription(object@data[["expInf"]])),"\n")
            }
          })
####                                       ####<< methods >>####
####                                       ####< init >####
initSplicingCompass<-function(x,countTable){
  x@data[["countTable"]]=countTable
  x@data[["expInf"]]=getExperimentInfo(x@data[["countTable"]])
  return(x)
}
####                                       ####< compute angles >####
#### computes the angles between all pairwise vectors and performs one-sided t-tests if in-group-angles are smaller than between-group-angles
computePairWiseAnglesForEveryGene<-function(x,whichTab="tab",whichReadsToUse="all",nCores=1,method){
  stringsAsFactorOption=getOption("stringsAsFactors")
  options(stringsAsFactors=FALSE) 
  
  ### check for locfit when using glm
  if (method=="glm" && !any(grepl("package:locfit",search()))) {  ## check for package:locfit
    stop("please attach locfit package when using glm method")
  }
  
  
  expInf=x@data[["expInf"]]

                                        #+ exon and junction reads counts 
  summedCovs=.getReadCountsForPairWiseComparison(x,whichTab=whichTab,whichReadsToUse=whichReadsToUse)
  summedCovsSplit=split(subset(summedCovs,select=-gene_id),list(summedCovs[,"gene_id"]))
  geneNames=names(summedCovsSplit)
  
  #summedCovsSpit: für jedes Gen jedes Sample die ExonCounts
  #ähnlich zu featureCounts von DEXSeq, umformatieren nötig
  #featureCounts=summedCovs
  #rownames(featureCounts)=paste(c(featureCounts[,"gene_id"]),rownames(featureCounts),sep=":")
  #featureCountsSplit=subset(featureCounts,select=-gene_id)
  #ab jetzt DEXSeq:
  #normFactors <- estimateSizeFactorsForMatrix(featureCountsSplit, median)
  #sizeFactors <- rep(normFactors, 2)
  #maxExons <- length( unique( x@tab$exonNumber ) )
  #object@modelFrameBM$sizeFactor <- rep(normFactors, each=maxExons)
  
                                        #+ pairInSameGroupInfo
  pairInSameGroupInfo=t(combn(1:length(getSampleDescriptions(expInf)),2))
  sameGroup=apply(pairInSameGroupInfo,1, 
    function(row){
      return(all(row %in% getGroupInfo(expInf)[[1]]$sampleNums) |
             all(row %in% getGroupInfo(expInf)[[2]]$sampleNums))
    })
  pairInSameGroupInfo=cbind(pairInSameGroupInfo,sameGroup)  #Kombinationen aller Sampels, mit Info ob in selber Gruppe
  
                                        #+ calculate pairwise angles and test sameGroup vs diffGroup for every gene
  tmp=NULL
  performTTest=(method=="tTest")
  if (nCores>1){ 
    if (any(grepl("package:parallel",search()))) {  ## check for package:parallel
      cat(paste("using",nCores,"cores "))
    } else if (any(grepl("package:multicore",search()))) { ## multicore depreciated, not recommended
      cat(paste("using",nCores,"cores "))
    } else {
      options(stringsAsFactors=stringsAsFactorOption)
      stop("Please attach parallel package when choosing nCores > 1 \n")
    }
    tmp=mclapply(summedCovsSplit,.calcPairWiseAnglesAndGetPVal,pairInSameGroupInfo,performTTest,mc.preschedule=TRUE,mc.silent=FALSE,mc.cores=nCores)
  } else {
    tmp=lapply(summedCovsSplit,.calcPairWiseAnglesAndGetPVal,pairInSameGroupInfo,performTTest)
  }
  
  if(method=="glm"){
    #glm Method
    #get list of angles for each gene
    allAnglesList <- data.frame(matrix(unlist(tmp), nrow=length(tmp), byrow=T))
    allAnglesList <- allAnglesList[-c(ncol(allAnglesList))]
    allAnglesList <- allAnglesList[-c(ncol(allAnglesList))]
    colnames(allAnglesList) <- colnames(tmp[[1]]$pairWiseAnglesCurrentGene)
    rownames(allAnglesList) <- names(tmp)
    #allAnglesList <- allAnglesList[complete.cases(allAnglesList),]
    sameOthersGroupInfo <- replace(pairInSameGroupInfo[,3], pairInSameGroupInfo[,3]==1,"same")
    sameOthersGroupInfo <- replace(sameOthersGroupInfo, sameOthersGroupInfo==0,"other")
    sameOthersGroupInfo <- factor(sameOthersGroupInfo)
    #y <- DGEList(counts=allAnglesList, group=pairInSameGroupInfo[,3]+1)
    #design <- model.matrix(~sameOthersGroupInfo)
    #y <- estimateDisp(y,design,robust=TRUE)
    #dispersion <- y$trended.dispersion
    #fit <- glmQLFit(y,design,dispersion=dispersion,robust=TRUE)
    #qlf <- glmQLFTest(fit)
    #for(i in rownames(qlf$table)){
    # tmp[[i]]$pVal<-qlf$table[i,]$PValue
    #}
    
    ##using quantiles:
    quant=quantile(unlist(allAnglesList),seq(0,1,.01),na.rm=TRUE)
    allAnglesList2 = allAnglesList
    replaceWQuantile=function(angle)
    {
      if(is.na(angle)) {return(NaN)}
      return(length(quant[quant <= angle])-1)
    }
    allAnglesList=as.data.frame(apply(allAnglesList,c(1,2),replaceWQuantile))
    
    calcQMatrix = function(row)
    {
      rowtmp=c(1/length(which(sameOthersGroupInfo %in% "same"))*sum(allAnglesList[row,which(sameOthersGroupInfo %in% "same")],na.rm=TRUE),
               1/length(which(sameOthersGroupInfo %in% "other"))*sum(allAnglesList[row,which(sameOthersGroupInfo %in% "other")],na.rm=TRUE))
      return(rowtmp)
    }
    
    q=t(mcmapply(calcQMatrix,1:nrow(allAnglesList),mc.cores = nCores))
    rownames(q)=rownames(allAnglesList)
    colnames(q)=c("same","other")
    
    calcWMatrix = function(row)
    {
      rowtmp=c((1/(length(which(sameOthersGroupInfo %in% "same"))-1))*sum((allAnglesList[row,which(sameOthersGroupInfo %in% "same")]-q[row,"same"])^2,na.rm=TRUE),
               (1/(length(which(sameOthersGroupInfo %in% "other"))-1))*sum((allAnglesList[row,which(sameOthersGroupInfo %in% "other")]-q[row,"other"])^2,na.rm=TRUE))
      return(rowtmp)
    }
    
    w=t(mcmapply(calcWMatrix,1:nrow(allAnglesList),mc.cores = nCores))
    rownames(w) = rownames(allAnglesList)
    colnames(w)=c("same","other")
    qnonzero = q[which(!apply(q==0,1,all)),]
    wnonzero = w[which(!apply(w==0,1,all)),]
    qnonzero = qnonzero[rownames(qnonzero) %in% rownames(wnonzero),]
    wnonzero = wnonzero[rownames(wnonzero) %in% rownames(qnonzero),]
    #dA = data.frame(logDisps = log(wnonzero[,"same"]+1e-9), logMeans=log(qnonzero[,"same"]+1e-9))
    dA = data.frame(logDisps = log(wnonzero[,"same"]), logMeans=log(qnonzero[,"same"]))
    dA = dA[is.finite(dA$logDisps),]
    #dB = data.frame(logDisps = log(wnonzero[,"other"]+1e-9), logMeans=log(qnonzero[,"other"]+1e-9))
    dB = data.frame(logDisps = log(wnonzero[,"other"]), logMeans=log(qnonzero[,"other"]))
    dB = dB[is.finite(dB$logDisps),]
    
    #fitA = locfit(logDisps~logMeans, data=dA, weights=qnonzero)
    #fitB = locfit(logDisps~logMeans, data=dB, weights=qnonzero)
    fitA = locfit(logDisps~logMeans, data=dA)
    fitB = locfit(logDisps~logMeans, data=dB)
    
    dispFunctionA <- function(means) exp(predict(fitA, data.frame(logMeans=log(means))))
    dispFunctionB <- function(means) exp(predict(fitB, data.frame(logMeans=log(means))))
    #plot(log(q[,"same"]),log(w[,"same"]))
    #lines(fit, col=2, lwd = 2)
    
    print("halfway through....")
    
    #angleSums = rowSums(allAnglesList, na.rm=TRUE)
    #use rowMeans(allAnglesList) instead?
    angleMeans = ceiling(rowMeans(allAnglesList, na.rm=TRUE))
    #qizero = angleSums[angleSums != 0]
    qizero = angleMeans[complete.cases(angleMeans)]
    qizero = qizero[qizero != 0]
    
    kiA = ceiling(rowMeans(allAnglesList[which(sameOthersGroupInfo %in% "same")],na.rm=TRUE))
    #kiA = kiA[kiA != 0]
    kiA = kiA[complete.cases(kiA)]
    kiA = kiA[names(kiA) %in% names(qizero)]
    kiA = kiA[names(kiA) %in% names(qnonzero)]
    kiB = ceiling(rowMeans(allAnglesList[which(sameOthersGroupInfo %in% "other")],na.rm=TRUE))
    #kiB = kiB[kiB != 0]
    kiB = kiB[complete.cases(kiB)]
    kiB = kiB[names(kiB) %in% names(qizero)]
    kiB = kiB[names(kiB) %in% names(kiA)]
    kiA = kiA[names(kiA) %in% names(kiB)]
    kiS = qizero
    kiS = kiS[names(kiS) %in% names(kiA)]
    qnonzero = as.data.frame(qnonzero)
    qnonzero = qnonzero[rownames(qnonzero) %in% names(kiA),]
    qnonzero = ceiling(qnonzero)
    
    cat("calculating mu and sigma")
    
    muA = kiS * length(which(sameOthersGroupInfo== "same"))
    #muA = kiA * length(which(sameOthersGroupInfo== "same"))
    #muA = kiA
    muB = kiS * length(which(sameOthersGroupInfo== "other"))
    #muB = kiB * length(which(sameOthersGroupInfo== "other"))
    #muB = kiB
    
    sigma2A = (kiS+dispFunctionA(kiS)) *length(which(sameOthersGroupInfo== "same"))
    #sigma2A = (kiA+dispFunctionA(kiA+1e-9)) *length(which(sameOthersGroupInfo== "same"))
    #sigma2A = (kiA+dispFunctionA(kiA))
    #sigma2A = apply(allAnglesList[which(sameOthersGroupInfo %in% "same")],1,var, na.rm=TRUE)
    #sigma2A = sigma2A[names(sigma2A) %in% names(kiA)]
    sigma2B = (kiS+dispFunctionB(kiS))*length(which(sameOthersGroupInfo== "other"))
    #sigma2B = (kiB+dispFunctionB(kiB+1e-9))*length(which(sameOthersGroupInfo== "other"))
    #sigma2B = apply(allAnglesList[which(sameOthersGroupInfo %in% "other")],1,var, na.rm=TRUE)
    #sigma2B = sigma2B[names(sigma2B) %in% names(kiB)]
        
    #rnbiom:
    #var = (r*(1-p))/p²
    #mean = (r*(1-p))/p
    # -> p = mean/var
    # -> r = p*mean/(1-p)
    pA = muA/sigma2A
    pB = muB/sigma2B
    rA = pA*muA/(1-pA)
    #rA = rbind(1,muA)[1,]
    rB = pB*muB/(1-pB)
    #rB = rbind(1,muB)[1,]
    
    #propability function: (k+r-1 over k)*p^r(1-p)^k
    probFuncA = function(k) choose(k+rA-1,k)*pA^rA*(1-pA)^k
    probFuncAi = function(k, i) choose(k+rA[i]-1,k)*pA[i]^rA[i]*(1-pA[i])^k
    probFuncB = function(k) choose(k+rB-1,k)*pA^rB*(1-pB)^k
    probFuncBi = function(k, i) choose(k+rB[i]-1,k)*pA[i]^rB[i]*(1-pB[i])^k
    
    
    cat("calculating sum1")
    
    #create empty data frame with enough columns
    #sum1 = data.frame(matrix(NA,ncol=max(kiA+kiB)))
    #sum1 = data.frame(matrix(NA,ncol=max(qnonzero[,"same"]+qnonzero[,"other"])))
    
    sumFunc1 = function(row){
      newrow = 1:(row)
      length(newrow) = max(qnonzero[,"same"]+qnonzero[,"other"])
      return(newrow)
    }
    
    sum1=t(mcmapply(sumFunc1,rowSums(qnonzero),mc.cores = nCores))
    
    
    #for(row in 1:length(kiS))
    #{
    #  newrow = 1:(kiA[row]+kiB[row])
    #  length(newrow) = max(kiA+kiB)
    #  sum1 = rbind(sum1, newrow)
    #}
    rownames(sum1) = rownames(qnonzero)
    
    cat("calculating sum2")
    
    #sum2 = data.frame(matrix(NA,ncol=max(kiA+kiB)))
    #sum2 = data.frame(matrix(NA,ncol=max(qnonzero["same"]+qnonzero["other"])))
    
    sumFunc2 = function(row){
      newrow = (row-1):0
      length(newrow) = max(qnonzero[,"same"]+qnonzero[,"other"])
      return(newrow)
    }
    
    sum2=t(mcmapply(sumFunc2,rowSums(qnonzero),mc.cores = nCores))
    
    
    #for(row in 1:length(kiS))
    #{
    #  newrow = (kiA[row]+kiB[row])-1:(kiA[row]+kiB[row])
    #  length(newrow) = max(kiA+kiB)
    #  sum2 = rbind(sum2, newrow)
    #}
    rownames(sum2) = rownames(qnonzero)
    
    psum1 = apply(sum1, 2, probFuncA)
    psum2 = apply(sum2, 2, probFuncB)
    pmatrix = psum1*psum2
    #pmatrix[is.na(pmatrix)]=0
    pmatrixsum = rowSums(pmatrix, na.rm = TRUE)
    
    #pkakb = probFuncA(kiA)*probFuncB(kiB)
    
    calcpab = function(a, b)
    {
      prob=0
      for(i in 1:length(a))
      {
        min = min(a[i],b[i])
        max = max(a[i],b[i])
        min = min-1
        max = max+1
        probi = 0
        while(min >= 0)
        {
          if(a[i]<b[i])
          {
            probi = probi + probFuncAi(min,i)*probFuncBi(max,i)
          }
          else
          {
            probi = probi + probFuncAi(max,i)*probFuncBi(min,i)
          }
          min = min-1
          max = max+1
        }
        prob[i]=probi
      }
      return(prob)
    }
    
    
    #calcpab = function(a, b)
    #{
    #  prob=0
    #  for(i in 1:length(a))
    #  {
    #    pkakb = probFuncAi(a[i],i)*probFuncBi(b[i],i)
    #    prob[i] = sum(pmatrix[i,][pmatrix[i,] <= pkakb], na.rm=TRUE)
    #  }
    #  return(prob)
    #}
    
    cat("calculating pvalues")
    
    #pab = calcpab(kiA,kiB)
    pab = calcpab(qnonzero[,"same"],qnonzero[,"other"])
    pvi = pab/pmatrixsum
    View(pvi)
    #design= model.matrix(~0+sameOthersGroupInfo)
    #colnames(design)=c("same","other")
    #fit=lmFit(allAnglesList,design)
    #contrast=makeContrasts(same_other=same-other, levels=design)
    #contrasts.fit=contrasts.fit(fit,contrast)
    #ebFit = eBayes(contrasts.fit)
    #same_other=topTable(ebFit, n=Inf)
    
    for(i in names(tmp))
    {
      tmp[[i]]$pVal=unname(pvi[i])
      #tmp[[i]]$pVal=same_other[i,"P.Value"]
    }
  }
  
  print("done")
  
  tmp2=as.data.frame(do.call("rbind",lapply(tmp,function(el){return(el$pairWiseAnglesCurrentGene)})))
  tmp3=cbind(gene_id=names(tmp),tmp2)
  tmp4=do.call("rbind",lapply(tmp,function(el){return(el$pVal)}))
  tmp5=do.call("rbind",lapply(tmp,function(el){return(el$pVal)}))
  m=cbind(tmp3,tTestPairWiseAngles=tmp4)
  x@data[["Tvals"]]=tmp5

                                        #+ return
  desc=paste("anglesPairWise",whichReadsToUse,sep="_") ## anglesPairWise_all or anglesPairWise_exonWithSkipJunctionsAndNonConsecJunction
  x@data[[desc]]=m
  options(stringsAsFactors=stringsAsFactorOption)
  return(x)
}
.getReadCountsForPairWiseComparison<-function(x,whichTab,whichReadsToUse){
  stopifnot(whichReadsToUse %in% c("all","exonWithSkipJunctionsAndNonConsecJunction"))

  expInf=x@data[["expInf"]]
  smplDescs=getSampleDescriptions(expInf)

  summedCovs=getSummedCovsFromCountTable(x@data[["countTable"]],whichTab,additionalColNames=c("gene_id","unique_id","exonNumber"),reorderCols=FALSE)
                                        #+ add splice junction reads to matrix if available
  if (!is.null(x@data[["countTable"]]@tabList[["junctionReadTab"]])){
    junctionReadTab=x@data[["countTable"]]@tabList[["junctionReadTab"]]
    junctionReadTabNonConsec=subset(junctionReadTab,consJunction==FALSE)
                                        # get column numbers for gene_id and read counts
    colsToChooseJuncReads=sapply(smplDescs,function(el){grep(paste(el,"$",sep=""),names(junctionReadTab))})
    colsToChooseJuncReads=c(colsToChooseJuncReads,gene_id=match("gene_id",names(junctionReadTab)))
    colsToChooseExonReads=sapply(smplDescs,function(el){grep(paste(el,"$",sep=""),names(summedCovs))})
    colsToChooseExonReads=c(colsToChooseExonReads,gene_id=match("gene_id",names(summedCovs)))
                                        # juncReads
    juncReads=junctionReadTab[,colsToChooseJuncReads]
    colnames(juncReads)=c(smplDescs,"gene_id")
    rownames(juncReads)=paste("juncReads",1:nrow(juncReads),sep="_")
                                        # juncReadsNonConsec
    juncReadsNonConsec=junctionReadTabNonConsec[,colsToChooseJuncReads]
    colnames(juncReadsNonConsec)=c(smplDescs,"gene_id")
    rownames(juncReadsNonConsec)=paste("juncReadsNonConsec",1:nrow(juncReadsNonConsec),sep="_")
                                        # exonReads
    exonReads=summedCovs[,colsToChooseExonReads]
    colnames(exonReads)=c(smplDescs,"gene_id")
    rownames(exonReads)=paste("exonReads",1:nrow(exonReads),sep="_")
                                        # firstLastExonReads
    firstLastExonReads=subset(summedCovs,exonNumber==1 | exonNumber==-1)
    firstLastExonReads=firstLastExonReads[,colsToChooseExonReads]
    colnames(firstLastExonReads)=c(smplDescs,"gene_id")
    rownames(firstLastExonReads)=paste("firstLastExonReads",1:nrow(firstLastExonReads),sep="_")
                                        # exonReadsWithSkipJunctions
    exonReadsWithSkipJunctionsUniqueIDs=.getExonReadsWithSkipJunctionsUniqueIDs(junctionReadTabNonConsec)
    exonReadsWithSkipJunctions=summedCovs[summedCovs[,"unique_id"] %in% exonReadsWithSkipJunctionsUniqueIDs,colsToChooseExonReads]
    colnames(exonReadsWithSkipJunctions)=c(smplDescs,"gene_id")
    rownames(exonReadsWithSkipJunctions)=paste("exonReads",1:nrow(exonReadsWithSkipJunctions),sep="_")

    if (whichReadsToUse=="all") summedCovs=rbind(juncReads,exonReads)
    if (whichReadsToUse=="exonWithSkipJunctionsAndNonConsecJunction"){
      summedCovs=rbind(exonReadsWithSkipJunctions,juncReadsNonConsec)
      summedCovs=rbind(summedCovs,firstLastExonReads)
    }
  }
  return(summedCovs)
}
.getExonReadsWithSkipJunctionsUniqueIDs<-function(junctionReadTabNonConsec){
  exonReadsWithSkipJunctionsUniqueIDs=junctionReadTabNonConsec[,"ExonNested"]
  exonReadsWithSkipJunctionsUniqueIDs=na.omit(exonReadsWithSkipJunctionsUniqueIDs)
  exonReadsWithSkipJunctionsUniqueIDs=unlist(sapply(exonReadsWithSkipJunctionsUniqueIDs,.parseUniqueIDs)) ## "id;id" -> "id" "id"
  return(exonReadsWithSkipJunctionsUniqueIDs)
}
#### "id;id" -> "id" "id"
.parseUniqueIDs<-function(uniqueIDs){
  res=unlist(strsplit(uniqueIDs,";"))
  return(res)
}
.calcPairWiseAnglesAndGetPVal<-function(summedCovsCurrentGene,pairInSameGroupInfo,performTTest){
  res=list()
  tmpRes=.calcPairWiseAngles(summedCovsCurrentGene,pairInSameGroupInfo)
  res[["pairWiseAnglesCurrentGene"]]=tmpRes[["pairWiseAnglesCurrentGene"]]
  if(performTTest){
    tmp=try(t.test(tmpRes[["anglesSameGroup"]],tmpRes[["anglesDiffGroup"]],alternative="less"),silent=TRUE)
    if (is(tmp,"try-error")){
      res[["pVal"]]=NA
      res[["tVal"]]=NA
    } else {
      res[["pVal"]]=tmp$p.value
      res[["tVal"]]=unname(tmp$statistic)
    }
  } else {
    res[["pVal"]]=NA
    res[["tVal"]]=NA
  }
  return(res)
}
.calcPairWiseAngles<-function(summedCovsCurrentGene,pairInSameGroupInfo){
  ## TODO check summedCovsCurrentGene against expInf
  pairWiseAnglesTmp=list()
  anglesSameGroup=numeric()
  anglesDiffGroup=numeric()
  for (j in 1:nrow(pairInSameGroupInfo)){
    ca=.getAngle(summedCovsCurrentGene[,pairInSameGroupInfo[j,1]],summedCovsCurrentGene[,pairInSameGroupInfo[j,2]])
    pairWiseAnglesTmp[[paste(pairInSameGroupInfo[j,1],pairInSameGroupInfo[j,2],sep="_")]]=ca
    if (pairInSameGroupInfo[j,"sameGroup"])
      {
        anglesSameGroup=c(anglesSameGroup,ca)
      } else {
        anglesDiffGroup=c(anglesDiffGroup,ca)
      }
  }
  pairWiseAnglesCurrentGene=do.call("cbind",pairWiseAnglesTmp)

  res=list()
  res[["pairWiseAnglesCurrentGene"]]=pairWiseAnglesCurrentGene
  res[["anglesSameGroup"]]=anglesSameGroup
  res[["anglesDiffGroup"]]=anglesDiffGroup
  return(res)
}
.getLength<-function(v){
  return(sqrt(sum(v*v)))
}
.getAngle<-function(v1,v2){
  v1=as.numeric(v1) # avoids integer overflow
  v2=as.numeric(v2) # avoids integer overflow
  l1=.getLength(v1)
  l2=.getLength(v2)

  cosAlpha=sum(v1*v2)/(l1*l2)
  if(isTRUE(all.equal(cosAlpha,1))){ cosAlpha=1 } ## avoid NaN in acos

  rad=acos(cosAlpha)
  grad=rad*180/pi
  return(grad)
}
####                                       ####< filter  >#### 
dropResultsForGenesWithOneExon<-function(x){
  tab=getStdTab(x@data[["countTable"]])
  tabSplit=split(tab,list(tab[,"gene_id"])) 
  oneExon=lapply(tabSplit,function(el){return(nrow(el)==1)})
  genesWithOneExon=names(oneExon[as.logical(oneExon)])
  x=.dropGenesFromResults(x,genesWithOneExon)
  return(x)
}
dropResultsForGenesWithLowExpression<-function(x,drop=c("infiniteValAfterDivByL","notExpressedInGroup1","notExpressedInGroup2","notExpressedInBoth")){
  exp=getGeneExpressionInfo(x@data[["countTable"]])
  toDrop=subset(exp,expressionInfo %in% drop)[,"gene_id"]
  x=.dropGenesFromResults(x,toDrop)
  return(x)
}
dropResultsForGenesWithZeroMedianInExpression<-function(x){
  tab=subset(getStdTab(x@data[["countTable"]]),select=c("gene_id","flagZeroMedianInGeneExpression"))
  genesToDrop=unique(subset(tab,flagZeroMedianInGeneExpression==TRUE,select=gene_id))[,"gene_id"]
  x=.dropGenesFromResults(x,genesToDrop)
  return(x)
}
.dropGenesFromResults<-function(x,geneIDs){
  x=..dropGenesFromResults(x,geneIDs,tabName="anglesPairWise_all")
  x=..dropGenesFromResults(x,geneIDs,tabName="anglesPairWise_exonWithSkipJunctionsAndNonConsecJunction")
  return(x)
}
..dropGenesFromResults<-function(x,geneIDs,tabName){
  if(is.null(x@data[[tabName]])){
    cat(paste("================",tabName,"unknown===============\n"))
    return(x)
  }
  x@data[[tabName]]=subset(x@data[[tabName]],!(gene_id %in% geneIDs))
  return(x)
}
filterResults<-function(x){
  .filterResults(x,tabName="anglesPairWise_all",pValColName="tTestPairWiseAngles")
  .filterResults(x,tabName="anglesPairWise_exonWithSkipJunctionsAndNonConsecJunction",pValColName="tTestPairWiseAngles")
  return(x)
}
.filterResults<-function(x,tabName,pValColName){
  if (is.null(x@data[[tabName]])){
    cat(paste("\n=================",tabName,"unknown=================\n"))
    return(x)
  }
        
  toDrop=is.na(x@data[[tabName]][,pValColName])
  x@data[[tabName]]=x@data[[tabName]][!toDrop,]

  NAElInRow=apply(x@data[[tabName]],1,function(row){return(any(is.na(row)))})
  x@data[[tabName]]=x@data[[tabName]][!NAElInRow,]

  return(x)
}
####                                       ####< combined  >####
#### x@data[["anglesPairWise_combined"]]
##' calculates Angles from both groups combined
##' @title addAnglesPairWiseCombined
##' @param x splicing compass object
##' @export
addAnglesPairWiseCombined<-function(x){
                                        # combine tests
  tmp=rbind(x@data[["anglesPairWise_all"]],x@data[["anglesPairWise_exonWithSkipJunctionsAndNonConsecJunction"]])

                                        # multiple testing correction for all performed tests
  tmp[,"tTestPairWiseAnglesPValHochberg"]=p.adjust(tmp[,"tTestPairWiseAngles"],method="hochberg")

                                        # choose minimal pval per gene
  tmpSplit=split(tmp,list(tmp$gene_id))
  #tmpMin=lapply(tmpSplit,function(el){return(el[which.min(el[,"tTestPairWiseAnglesPValHochberg"]),])})
  tmpMin=lapply(tmpSplit,function(el){return(el[which.min(el[,"tTestPairWiseAngles"]),])})
  tmpMin=do.call("rbind",tmpMin)

  x@data[["anglesPairWise_combined"]]=tmpMin
  return(x)
}
####                                       ####<< INTERFACE >>####
####                                       ####< construction >####
##' Constructs an object of class SplicingCompass
##'
##' Calculates geometric angles between read count vectors represented in countTable
##' and predicts differentially spliced genes.
##' @title constructSplicingCompass
##' @param x object of class SplicingCompass
##' @param countTable object of class CountTable
##' @param minOverallJunctionReadSupport minimal number of junction reads (summed over all samples) required to support a junction (defaults to 5)
##' @param nCores number of cores to use for computation. If nCores > 1, the "multicore" package has to be loaded via "library("multicore")"
##' @return object of class SplicingCompass
##' @author Moritz Aschoff
##' @export
constructSplicingCompass<-function(x,countTable,minOverallJunctionReadSupport=5,nCores=1,method="tTest"){
  stopifnot(method %in% c("tTest","glm"))
  cat(">>>>>>>>>>>>>>>>>> constructing SplicingCompass object <<<<<<<<<<<<<<<<<<<<<<<<<<<\n")

  x=initSplicingCompass(x,countTable) ## countTable, expInf
  x@data[["countTable"]]=filterJunctionReadTab(x@data[["countTable"]],minSumScore=minOverallJunctionReadSupport)
                                        #+ compute angles and pvals
  cat("Computing pairwise splicing angles step 1/2...") ## set x@data[["anglesPairWise_all"]]:
  x=computePairWiseAnglesForEveryGene(x,whichTab="tab",whichReadsToUse="all",nCores=nCores,method) 
  cat("done\n")
  cat("Computing pairwise splicing angles step 2/2...") ## set x@data[["anglesPairWise_exonWithSkipJunctionsAndNonConsecJunction"]]:
  x=computePairWiseAnglesForEveryGene(x,whichTab="tab",whichReadsToUse="exonWithSkipJunctionsAndNonConsecJunction",nCores=nCores,method)
  cat("done\n")
                                        #+ filtering
  cat("Filtering ...")
  x=dropResultsForGenesWithOneExon(x); cat(".");
  x=dropResultsForGenesWithLowExpression(x,drop=c("infiniteValAfterDivByL","notExpressedInGroup1","notExpressedInGroup2","notExpressedInBoth")); cat(".");
  x=dropResultsForGenesWithZeroMedianInExpression(x); cat(".");
  x=filterResults(x) ## remove genes with NA angles and NA p-vals
  cat("done\n")
                                        #+ adjust p-values and finalise
  cat("Adjusting p-values and finalising...") ## set x@data[["anglesPairWise_combined"]]:
  x=addAnglesPairWiseCombined(x) 
  cat("done\n")

  return(x)
}
####                                       ####< get >####
##' Returns a character vector of significant gene symbols
##'
##' @title getSignificantGeneSymbols
##' @param x object of class SplicingCompass
##' @return character vector of significant gene symbols
##' @author Moritz Aschoff
##' @export
getSignificantGeneSymbols<-function(x){
  return(x@data[["topGenesTable"]][,"gene_id"])
}
##' Returns a table of all tested gene symbols and corresponding p-values
##'
##' @title getResultTable
##' @param x object of class SplicingCompass
##' @return a data frame
##' @author Moritz Aschoff
##' @export
getResultTable<-function(x){
  tab=x@data[["anglesPairWise_combined"]][,c("gene_id","tTestPairWiseAngles","tTestPairWiseAnglesPValHochberg")]
  tVals=x@data[["Tvals"]][rownames(x@data[["Tvals"]]) %in% rownames(tab)]
  #tab=cbind(tab,tVals)
  tab=tab[order(tab$tTestPairWiseAnglesPValHochberg),]
  return(tab)
}
##' Returns a vector of gene symbols that were actually tested (i.e. not pre-filtered) by SplicingCompass.
##'
##' @title getAllTestedGenes
##' @param x object of class SplicingCompass
##' @return object of class SplicingCompass
##' @author Moritz Aschoff
##' @export
getAllTestedGenes<-function(x){
  return(unique(x@data[["anglesPairWise_all"]][,"gene_id"])) 
}
####                                       ####< sigGenes >####
##' Select significant genes according to a given significance level. Significant gene symbols can be obtained via "getSignificantGeneSymbols".
##'
##' @title initSigGenesFromResults
##' @param x object of class SplicingCompass
##' @param threshold significance level (i.e threshold for p-value)
##' @param adjusted whether to use p-values adjusted for multiple testing by the Benjamini and Hochberg procedure or not (default = TRUE)
##' @return object of class SplicingCompass
##' @author Moritz Aschoff
##' @export
initSigGenesFromResults<-function(x,adjusted=TRUE,threshold=0.1){
  pValName=""
  if (!adjusted) {pValName="tTestPairWiseAngles"}
  if (adjusted) {pValName="tTestPairWiseAnglesPValHochberg"}

  keep=x@data[["anglesPairWise_combined"]][,pValName]<=threshold
  df=x@data[["anglesPairWise_combined"]][keep,]
  df=df[order(df[,pValName]),]
  allNA=apply(df,1,function(row) all(is.na(row)))
  df=df[!allNA,]
  x@data[["topGenesTable"]]=df
  return(x)
}
