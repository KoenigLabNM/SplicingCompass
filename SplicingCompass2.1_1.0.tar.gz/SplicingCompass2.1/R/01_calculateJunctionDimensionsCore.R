####                                       ####<< methods >>####
addExonNumberGFF<-function(gff) {
  gffSplit=split(gff,list(gff$geneSymbol))
  exonNumberList=lapply(gffSplit,FUN=.getExonNumbersGFF)
  ## do.call("rbind",...) very slow for data.frames
  ## cmp. http://stackoverflow.com/questions/5980240/performance-of-rbind-data-frame
  tmp=lapply(exonNumberList,function(el){
    m=matrix(el[,"exonNumber"],ncol=1)
    row.names(m)=el[,"unique_id"]
    return(m)
  })
  tmp2=do.call("rbind",tmp) ## much faster
  tmp3=data.frame(unique_id=row.names(tmp2),exonNumber=tmp2[,1])
  m=merge(gff,tmp3,by.x="unique_id",by.y="unique_id",all.x=TRUE)
  stopifnot(nrow(m)==nrow(gff))
  gff=m
  return(gff)
}
.getExonNumbersGFF<-function(gffOfOneGene){
  rnk=rank(gffOfOneGene$start)
  rnk[rnk==max(rnk)]=-1 # -1 denotes last exon
  res=data.frame(unique_id=gffOfOneGene["unique_id"],exonNumber=rnk)
  return(res)
}
####                                       ####< read and preprocess union reference >####
#### TODO getAttributeFieldRefFlat hard coded
readAndPreprocessReferenceAnnot<-function(expInf){
  cat("Reading reference annotation... ")
  refAnnotFile=getReferenceAnnotation(expInf)
  cat("\n Preprocessing reference annotation (this may take a couple of minutes)...")
  gff=gffRead(refAnnotFile)
  gff$geneSymbol=getAttributeFieldRefFlat(gff$attributes, "geneSymbol", attrsep = "; ")
  gff$mergedTranscriptIDs=getAttributeFieldRefFlat(gff$attributes, "mergedTranscriptIDs", attrsep = "; ")
  gff$unique_id=paste(gff$geneSymbol,gff$start,sep="_")
  gff=addExonNumberGFF(gff)
  gff$unique_id=paste(gff$unique_id,gff$exonNumber,sep="_")
  cat("done\n")
  return(gff)
}
####                                       ####< read junctions >####
#### reads all junction files represented in expInf
readAllJunctionBedFiles<-function(expInf){
  jbFileNames=getJunctionBedFiles(expInf)
  descs=getSampleDescriptions(expInf)
  res=list()
  for (i in 1:length(jbFileNames)){
    jbFileName=jbFileNames[i]
    cat(paste("processing",descs[i],"\n"))
    res[[descs[i]]]=read.table(
         jbFileName,skip=1,
         colClasses=c("character","numeric","numeric","character","numeric","character","numeric","numeric","character","numeric","character","character"),
         col.names=c("chrom","chromStart","chromEnd","name","score","strand","thickStart","thickEnd","itemRgb","blockCount","blockSizes","blockStarts"))
  }
  return(res)
}
####                                       ####< process junctions  >####
#### returns a single data.frame for provided qGeneSymbol, with all junctions merged from jbFiles. Connections of exons annotated in gff are reported.
tryGetMergedJunctionsForGene<-function(qGeneSymbol,gff,jbFiles,printDotPerGene=TRUE){
    res=try(getMergedJunctionsForGene(qGeneSymbol,gff,jbFiles,printDotPerGene))
    if (is(res,"try-error")) val=NA else val=res
    return(res)
  }
getMergedJunctionsForGene<-function(qGeneSymbol,gff,jbFiles,printDotPerGene=TRUE){
  if (printDotPerGene) cat(".")
  gene=subset(gff,geneSymbol==qGeneSymbol) 
  gene=gene[order(gene$start),]
  
  junctionsGene=list()
  for (i in 1:length(jbFiles)){
    ##cat(c(i," "))
    junctionsGene[[names(jbFiles)[i]]]=getJunctionsForGene(gff,junctions=jbFiles[[i]],gffOfOneGene=gene)
  }
  rslt=mergeJunctionsForGene(junctionsGene,minJuncSum=1)
  return(rslt)
}
#### returns all junctions in gene region and from correct strand and adds Exon1/2 info (i.e. which exons are connected by the junction)
getJunctionsForGene<-function(gff,junctions,gffOfOneGene){
  junctionsGene=getJunctionsInRegion(junctions,qChrom=unique(gffOfOneGene[,"seqname"]),qStart=min(gffOfOneGene[,"start"]),qEnd=max(gffOfOneGene[,"end"]))
  junctionsGene=subset(junctionsGene,strand==unique(gffOfOneGene$strand)) ## during mapping, junction reads are probably annotated with the correct strand by looking at the gt->ac orientation
  if (nrow(junctionsGene)>0) junctionsGene=mergeJunctionsFromSameSplit(junctionsGene) 
  junctionsGene=addColConnectsKnownConsecutiveExons(gffOfOneGene,junctionsGene)
  
  res=junctionsGene[,c("chrom","splitPos1","splitPos2","name","score","strand","Exon1","Exon2")]
  return(res)
}
#### removes junctions with same split positions
mergeJunctionsFromSameSplit<-function(junctions){
  res=NULL
  junctions$tmpID=paste(junctions[,"splitPos1"],junctions[,"splitPos2"],sep="_")
  tmpIDs=unique(junctions$tmpID)

  for (tmpID in tmpIDs){
    toMerge=junctions[junctions$tmpID == tmpID,]
    merged=toMerge[0,]
    merged[1,]=NA
    merged$chrom=unique(toMerge$chrom)
    merged$chromStart=-1
    merged$chromEnd=-1
    merged$name=paste(toMerge$name,collapse="_")
    merged$score=sum(toMerge$score)
    merged$strand=paste(unique(toMerge$strand),collapse="_")
    merged$thickStart=-1
    merged$thickEnd=-1
    merged$itemRgb=paste(unique(toMerge$itemRgb),collapse="_")
    merged$blockCount=-1
    merged$blockSizes=-1
    merged$blockStarts=-1
    merged$blockSize1=-1
    merged$blockSize2=-1
    merged$splitPos1=unique(toMerge$splitPos1)
    merged$splitPos2=unique(toMerge$splitPos2)
    merged$tmpID=NULL
    res=rbind(res,merged)
  }
  
  return(res)
}
#### returns all junctions in defined region and adds splitPos info
getJunctionsInRegion<-function(junctionsTMP,qChrom,qStart,qEnd){
  junctionsTMPGene=subset(junctionsTMP,chrom==qChrom & chromStart > qStart & chromEnd < qEnd)
  junctionsTMPGene=junctionsTMPGene[order(junctionsTMPGene$chromStart),]
  
  m=matrix(as.numeric(unlist(strsplit(junctionsTMPGene[,"blockSizes"],","))),ncol=2,byrow=TRUE)
  colnames(m)=c("blockSize1","blockSize2")
  junctionsTMPGene=cbind(junctionsTMPGene,m)
  junctionsTMPGene[,"splitPos1"]=junctionsTMPGene[,"chromStart"]+junctionsTMPGene[,"blockSize1"]
  junctionsTMPGene[,"splitPos2"]=junctionsTMPGene[,"chromEnd"]-junctionsTMPGene[,"blockSize2"]+1

  return(junctionsTMPGene)
}
##' adds Exon1/2 column indicating which exons are connected by every junction 
##' @title addColConnectsKnownConsecutiveExons
##' @param gene gene
##' @param junctionsGene junctionsGene
##' @export
addColConnectsKnownConsecutiveExons<-function(gene,junctionsGene){
  if (nrow(junctionsGene)==0){
    junctionsGene$Exon1=logical(0)
    junctionsGene$Exon2=logical(0)
    return(junctionsGene)
  }
  junctionsGene$Exon1=NA
  junctionsGene$Exon2=NA
  
  gene$uniqueCol1=paste(gene$seqname,gene$end,gene$strand,sep="_")
  gene$uniqueCol2=paste(gene$seqname,gene$start,gene$strand,sep="_")
  junctionsGene$uniqueCol1=paste(junctionsGene$chrom,junctionsGene$splitPos1,junctionsGene$strand,sep="_")
  junctionsGene$uniqueCol2=paste(junctionsGene$chrom,junctionsGene$splitPos2,junctionsGene$strand,sep="_")

  m1=merge(gene,junctionsGene,by.x="uniqueCol1",by.y="uniqueCol1") ## first part of junction
  m2=merge(gene,junctionsGene,by.x="uniqueCol2",by.y="uniqueCol2") ## second part of junction

  if (nrow(m1)>0) m1$junctionPart="first" else m1$junctionPart=logical(0)
  if (nrow(m2)>0) m2$junctionPart="second" else m2$junctionPart=logical(0)
  m=rbind(m1[,c("unique_id","name","junctionPart","score.y")],m2[,c("unique_id","name","junctionPart","score.y")])
  if (nrow(m)==0) return(junctionsGene) 

  for (i in 1:nrow(junctionsGene)){
    connectedExons=m[m$name == junctionsGene[i,"name"],]
    if (nrow(connectedExons)==0){ next() }
    if (nrow(connectedExons)==1){
      if(connectedExons[1,"junctionPart"]=="first"){ junctionsGene[i,"Exon1"]=connectedExons[1,"unique_id"] }
      if(connectedExons[1,"junctionPart"]=="second"){ junctionsGene[i,"Exon2"]=connectedExons[1,"unique_id"] }
    } 
    if (nrow(connectedExons)==2){
      junctionsGene[i,"Exon1"]=connectedExons[connectedExons$junctionPart=="first","unique_id"]
      junctionsGene[i,"Exon2"]=connectedExons[connectedExons$junctionPart=="second","unique_id"]
    }
    if (nrow(connectedExons)>2){ stop("Junction connects more than two exons?\n") }
  }

                                        # recover NA
  sourceExonsUnknown=which(is.na(junctionsGene$Exon1))
  for (sourceExonUnknown in sourceExonsUnknown){
    posSourceExon=junctionsGene[sourceExonUnknown,"splitPos1"]
    strandSourceExon=junctionsGene[sourceExonUnknown,"strand"]
    sourceExon=subset(gene,start<=posSourceExon & posSourceExon<=end & strand == strandSourceExon,select="unique_id")[1,]
    if(!is.na(sourceExon)){
      junctionsGene[sourceExonUnknown,"Exon1"]=paste(sourceExon,"alt",sep="_")
    }
  }

  targetExonsUnknown=which(is.na(junctionsGene$Exon2))
  for (targetExonUnknown in targetExonsUnknown){
    posTargetExon=junctionsGene[targetExonUnknown,"splitPos2"]
    strandTargetExon=junctionsGene[targetExonUnknown,"strand"]
    targetExon=subset(gene,start<=posTargetExon & posTargetExon<=end & strand == strandTargetExon,select="unique_id")[1,]
    if(!is.na(targetExon)){
      junctionsGene[targetExonUnknown,"Exon2"]=paste(targetExon,"alt",sep="_")
    }
  }
  
  return(junctionsGene)
}
####                                       ####< merge junctions >####
#### merges junctionsGene in list format into single data.frame
#### junctions with less than minJuncSum read counts (over all experiments) are discarded
mergeJunctionsForGene<-function(junctionsGene,minJuncSum){
  cjuncs1=junctionsGene[[1]]
  cjuncs1=.addUniqueIDAndScoreName(cjuncs1,desc=names(junctionsGene)[1])
  cjuncs=cjuncs1
  
  for (i in 2:length(junctionsGene)){
    cjuncsToAdd=junctionsGene[[i]]
    cjuncsToAdd=.addUniqueIDAndScoreName(cjuncsToAdd,desc=names(junctionsGene)[i])
    cjuncs=.mergeJunctionsForGene(cjuncs,cjuncsToAdd)
  }
  cjuncsScores=cjuncs[,grepl("score_",names(cjuncs))]
  sumOfJuncs=apply(cjuncsScores,1,sum,na.rm=TRUE)
  rowsToKeep=sumOfJuncs>=minJuncSum
  return(cjuncs[rowsToKeep,])
}
#### merges two junction data.frames into one
.mergeJunctionsForGene<-function(cjuncs1,cjuncs2){
  m=merge(cjuncs1,cjuncs2,by.x="unique_id",by.y="unique_id",all.x=TRUE,all.y=TRUE)
  m$chrom=getValueNotNA(m$chrom.x,m$chrom.y)
  m$splitPos1=getValueNotNA(m$splitPos1.x,m$splitPos1.y)
  m$splitPos2=getValueNotNA(m$splitPos2.x,m$splitPos2.y)
  m$strand=getValueNotNA(m$strand.x,m$strand.y)
  m$Exon1=getValueNotNA(m$Exon1.x,m$Exon1.y)
  m$Exon2=getValueNotNA(m$Exon2.x,m$Exon2.y)
  baseCols=c("unique_id","chrom","splitPos1","splitPos2","strand","Exon1","Exon2")
  scoreCols=names(m)[grep("score_",names(m))]
  m=m[,c(baseCols,scoreCols)]
  return(m)
}
.addUniqueIDAndScoreName<-function(cjuncs,desc){
  names(cjuncs)=sub("score",paste("score",desc,sep="_"),names(cjuncs))
  cjuncs$unique_id=paste(cjuncs$chrom,cjuncs$strand,cjuncs$splitPos1,cjuncs$splitPos2,sep="_")
  if (any(duplicated(cjuncs$unique_id)))  stop("duplicated unique ids")
  return(cjuncs)
}
#### combines vec1 and vec2 into one vector. Equal elements are used. If one vec has a NA element, the element in the other vec is used.
getValueNotNA<-function(vec1,vec2){
  res=rep(NA,length(vec1))
  bothEqual=(vec1==vec2)
  bothEqual[is.na(bothEqual)]=FALSE
  res[bothEqual]=vec1[bothEqual]
  missing=is.na(res)
  res[missing]=vec1[missing]
  missing=is.na(res)
  res[missing]=vec2[missing]
  return(res)
}
####                                       ####< convertToOneMatrix >####
convertToOneMatrix<-function(junctionMatrices){
  geneIDs=names(junctionMatrices)
  pb=txtProgressBar(min = 0, max = length(junctionMatrices), style = 3)
  for (i in 1:length(junctionMatrices)){
    setTxtProgressBar(pb, i)
    if(nrow(junctionMatrices[[i]])>0) junctionMatrices[[i]]$gene_id=geneIDs[i]
  }
  close(pb)
  cat("doing rbind....")
  res=do.call("rbind",junctionMatrices)
  cat("done\n")
  return(res)
}
####                                       ####< postProcess junctions  >####
setNAJuncsToZero<-function(junctionMatrix){
  junctionMatrixScores=junctionMatrix[,grepl("score_",names(junctionMatrix))]
  junctionMatrixScores[is.na(junctionMatrixScores)]=0
  junctionMatrix[,grepl("score_",names(junctionMatrix))]=junctionMatrixScores
  return(junctionMatrix)
}
####                                       ####< checks >####
checkPoint_jbFiles<-function(expInf,gff,jbFiles){
                                        # 
  t1=all(getSampleDescriptions(expInf)==names(jbFiles))
  if (!t1) cat("========== not all junctions.bed files represented in the experiment info could be parsed ==============")

                                        #
  t2=all(unlist(lapply(jbFiles,nrow))>0)
  if (!t2) cat("========== some junctions.bed files are empty ==============")

                                        # check for compatibility between refAnnotFile and junctions.bed files
  chromsRefAnnot=unique(gff[,"seqname"])
  t3=rep(NA,length(jbFiles))
  for (i in 1:length(jbFiles)){
    chromsJBFile=unique(jbFiles[[i]][,"chrom"])
    ##t3[i]=all(chromsJBFile %in% chromsRefAnnot)
    t3[i]=length(intersect(chromsJBFile,chromsRefAnnot)>0)
  }
  t4=all(t3)
  if (!t4) cat("========== junctions.bed files and reference annotation seem to differ in the naming scheme of chromosomes ==============")

  return(t1 & t2 & t4)
}
####                                       ####< calculateJunctionDimensions  >####
calculateJunctionDimensions<-function(expInf,nCores=1,printDotPerGene=TRUE){
                                        #+ ref annot
  gff=readAndPreprocessReferenceAnnot(expInf)
  
  allGenes=unique(gff$geneSymbol)
  allGenesList=as.list(allGenes)
  names(allGenesList)=allGenes

                                        #+ junctions
  jbFiles=readAllJunctionBedFiles(expInf)
  if (!checkPoint_jbFiles(expInf,gff,jbFiles)) stop("Some problem occured in junctions.bed files and/or reference annotation")
  
  junctionMatrices=NULL
  if (nCores>1){
    if (any(grepl("package:parallel",search()))) {  ## check for package:parallel
      cat(paste("using",nCores,"cores "))
    } else if (any(grepl("package:multicore",search()))) { ## multicore depreciated, not recommended
      cat(paste("using",nCores,"cores "))
    } else {
      stop("Please attach parallel package when choosing nCores > 1 \n")
    }
    junctionMatrices=mclapply(allGenesList,tryGetMergedJunctionsForGene,gff,jbFiles,mc.preschedule=TRUE,mc.silent=FALSE,mc.cores=nCores,printDotPerGene)
  } else {
    junctionMatrices=lapply(allGenesList,tryGetMergedJunctionsForGene,gff,jbFiles,printDotPerGene)
  }
  
                                        #+ combine and filter
  junctionMatrix=convertToOneMatrix(junctionMatrices)
  junctionMatrix=setNAJuncsToZero(junctionMatrix)

  return(junctionMatrix)
}
