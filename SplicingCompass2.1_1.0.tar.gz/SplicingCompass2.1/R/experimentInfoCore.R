####                                       ####<< ExperimentInfo >>####
setClass("ExperimentInfo",
         representation=representation(
           data="list"))
####                                      ####<< get and set methods >>####
setMethod("show", signature="ExperimentInfo",
          function(object) {
            cat(paste("Experiment:",getDescription(object),"\n"))
          })
####                                        #+ Description
setGeneric("getDescription", function(x) standardGeneric("getDescription"))
setGeneric("setDescription", function(x,...) standardGeneric("setDescription"))
##' Returns a description of the experiment
##'
##' @title getDescription
##' @param x object of class ExperimentInfo
##' @return character string that describes the experiment
##' @author Moritz Aschoff
##' @method getDescription ExperimentInfo
##' @export
setMethod("getDescription",
          signature="ExperimentInfo",
          function(x){
            return(x@data[["description"]])
          }
          )
##' Sets a description for the experiment
##'
##' @title setDescription
##' @param x object of class ExperimentInfo
##' @param val character string that describes the experiment
##' @return object of class ExperimentInfo
##' @author Moritz Aschoff
##' @method setDescription ExperimentInfo
##' @export
setMethod("setDescription",
          signature="ExperimentInfo",
          function(x,val){
            x@data[["description"]]=val
            return(x)
          }
          )
####                                        #+ experimental design (GroupInfo)
setGeneric("getGroupInfo", function(x) standardGeneric("getGroupInfo"))
setGeneric("setGroupInfo", function(x,...) standardGeneric("setGroupInfo"))
##' Returns a description for the two groups that should be compared and the number of samples associated with each group
##'
##' @title getGroupInfo
##' @param x object of class ExperimentInfo
##' @return a nested list
##' @author Moritz Aschoff
##' @method getGroupInfo ExperimentInfo
##' @export
setMethod("getGroupInfo",
          signature="ExperimentInfo",
          function(x){
            return(x@data[["groupInfo"]])
          }
          )
##' Sets a description for the two groups that should be compared and the number of samples associated with each group
##'
##' The numbering must be consistent with the information provided in "setCovBedCountFiles"
##' @title setGroupInfo
##' @param x object of class ExperimentInfo
##' @param groupName1 character string that describes group 1 (must not contain whitespaces or special characters)
##' @param sampleNumsGroup1 numeric vector that indicates which samples (i.e. files provided via setCovBedCountFiles) belong to group 1
##' @param groupName2 character string that describes group 2 (must not contain whitespaces or special characters)
##' @param sampleNumsGroup2 numeric vector that indicates which samples (i.e. files provided via setCovBedCountFiles) belong to group 2
##' @return object of class ExperimentInfo
##' @author Moritz Aschoff
##' @method setGroupInfo ExperimentInfo
##' @export
setMethod("setGroupInfo",
          signature="ExperimentInfo",
          function(x,groupName1,sampleNumsGroup1,groupName2,sampleNumsGroup2){
            info=list(
              list(groupName=groupName1,sampleNums=sampleNumsGroup1),
              list(groupName=groupName2,sampleNums=sampleNumsGroup2))
            x@data[["groupInfo"]]=info
            x@data[["sampleDescriptions"]]=c(paste(groupName1,1:length(sampleNumsGroup1),sep="_"),paste(groupName2,1:length(sampleNumsGroup2),sep="_"))
            return(x)
          }
          )
#### SampleDescriptions
setGeneric("getSampleDescriptions", function(x) standardGeneric("getSampleDescriptions"))
##' returns a brief description of all samples in the experiment
##'
##' @title getSampleDescriptions
##' @param x object of class ExperimentInfo
##' @return chr vector with brief description of all samples in the experiment
##' @author Moritz Aschoff
##' @method getSampleDescriptions ExperimentInfo
setMethod("getSampleDescriptions",
          signature="ExperimentInfo",
          function(x){
            return(x@data[["sampleDescriptions"]])
          }
          )
####                                        #+ counting and mapping
#### CovBedCountFiles
setGeneric("getCovBedCountFiles", function(x) standardGeneric("getCovBedCountFiles"))
setGeneric("setCovBedCountFiles", function(x,...) standardGeneric("setCovBedCountFiles"))
##' Returns a vector with the file paths of read count files
##'
##' @title getCovBedCountFiles
##' @param x object of class ExperimentInfo
##' @return vector with the paths to output files from coverageBed that contain read counts
##' @author Moritz Aschoff
##' @method getCovBedCountFiles ExperimentInfo
##' @export
setMethod("getCovBedCountFiles",
          signature="ExperimentInfo",
          function(x){
            return(x@data[["covBedCountFiles"]])
          }
          )
##' Set paths to files that contain read counts
##'
##' See tutorial how to generate appropriate files with coverageBed. The order of the files must be consistent with the information provided in "setGroupInfo"
##' @title setCovBedCountFiles
##' @param x object of class ExperimentInfo
##' @param val vector with the paths to files that contain read counts
##' @return object of class ExperimentInfo
##' @author Moritz Aschoff
##' @method setCovBedCountFiles ExperimentInfo
##' @export
setMethod("setCovBedCountFiles",
          signature="ExperimentInfo",
          function(x,val){
            x@data[["covBedCountFiles"]]=val
            return(x)
          }
          )
#### junctionBedFiles
setGeneric("getJunctionBedFiles", function(x) standardGeneric("getJunctionBedFiles"))
setGeneric("setJunctionBedFiles", function(x,...) standardGeneric("setJunctionBedFiles"))
##' Returns a vector with the file paths of junction read files in bed format (e.g. as reported by TopHat)
##'
##' @title getJunctionBedFiles
##' @param x object of class ExperimentInfo
##' @return vector with the paths to junction read files (e.g. "junctions.bed" files reported from TopHat)
##' @author Moritz Aschoff
##' @method getJunctionBedFiles ExperimentInfo
##' @export
setMethod("getJunctionBedFiles",
          signature="ExperimentInfo",
          function(x){
            return(x@data[["junctionBedFiles"]])
          }
          )
##' Set paths to files that contain junction read files in bed format (e.g. as reported by TopHat)
##'
##' The order of the files must be consistent with the information provided in "setGroupInfo"
##' @title setJunctionBedFiles
##' @param x object of class ExperimentInfo
##' @param val vector with the paths to files that contain junction read files in bed format (e.g. "junctions.bed" files reported from TopHat)
##' @return object of class ExperimentInfo
##' @author Moritz Aschoff
##' @method setJunctionBedFiles ExperimentInfo
##' @export
setMethod("setJunctionBedFiles",
          signature="ExperimentInfo",
          function(x,val){
            x@data[["junctionBedFiles"]]=val
            return(x)
          }
          )
####                                        #+ ReferenceAnnotation
setGeneric("getReferenceAnnotation", function(x) standardGeneric("getReferenceAnnotation"))
setGeneric("setReferenceAnnotation", function(x,...) standardGeneric("setReferenceAnnotation"))
##' Returns the reference annotation used with CoverageBed
##'
##' @title getReferenceAnnotation
##' @param x object of class ExperimentInfo
##' @return list
##' @author Moritz Aschoff
##' @method getReferenceAnnotation ExperimentInfo
##' @export
setMethod("getReferenceAnnotation",
          signature="ExperimentInfo",
          function(x){
            return(x@data[["referenceAnnotation"]])
          }
          )
##' Sets the reference annotation used with CoverageBed
##'
##' @title setReferenceAnnotation
##' @param x object of class ExperimentInfo
##' @param filename
##' @return object of class ExperimentInfo
##' @author Moritz Aschoff
##' @method setReferenceAnnotation ExperimentInfo
##' @export
setMethod("setReferenceAnnotation",
          signature="ExperimentInfo",
          function(x,val){
            x@data[["referenceAnnotation"]]=val
            return(x)
          }
          )
setGeneric("getReferenceAnnotationFormat", function(x) standardGeneric("getReferenceAnnotationFormat"))
setGeneric("setReferenceAnnotationFormat", function(x,...) standardGeneric("setReferenceAnnotationFormat"))
##' Returns the format of the reference annotation used with CoverageBed
##'
##' @title getReferenceAnnotationFormat
##' @param x object of class ExperimentInfo
##' @return list
##' @author Moritz Aschoff
##' @method getReferenceAnnotationFormat ExperimentInfo
##' @export
setMethod("getReferenceAnnotationFormat",
          signature="ExperimentInfo",
          function(x){
            return(x@data[["referenceAnnotationFormat"]])
          }
          )
##' Sets the format of the reference annotation used with CoverageBed
##'
##' @title setReferenceAnnotationFormat
##' @param x object of class ExperimentInfo
##' @param val list with two elements: IDFieldName and idValSep
##' @return object of class ExperimentInfo
##' @author Moritz Aschoff
##' @method setReferenceAnnotationFormat ExperimentInfo
##' @export
setMethod("setReferenceAnnotationFormat",
          signature="ExperimentInfo",
          function(x,val){
            x@data[["referenceAnnotationFormat"]]=val
            return(x)
          }
          )
####                                        #+ checkExperimentInfo
setGeneric("checkExperimentInfo", function(x) standardGeneric("checkExperimentInfo"))
##' Does a simple check if the number of samples actually match the number of provided files
##' The New content checks for consistency in the given chromosome names in the input files
##'
##' @title checkExperimentInfo
##' @param x 
##' @return Chromosome names that will be used in further calculations and logical
##' @author Moritz Aschoff
##' @method checkExperimentInfo ExperimentInfo
##' @export
setMethod("checkExperimentInfo",
          signature="ExperimentInfo",
          function(x){
            t1=length(getGroupInfo(x)[[1]][["sampleNums"]])>1 & length(getGroupInfo(x)[[2]][["sampleNums"]])>1
            if (!t1) stop("Please provide more than one sample per experiment")
            
            s1=length(c(getGroupInfo(x)[[1]][["sampleNums"]],getGroupInfo(x)[[2]][["sampleNums"]]))
            s2=length(getSampleDescriptions(x))
            s3=length(getCovBedCountFiles(x))
            t2=length(unique(c(s1,s2,s3)))==1
            
############################################# New check content ##############################################################
            
            cat("Read CovBedCountFile: \n")
            for(i in getCovBedCountFiles(x)){
              cat(i,"\n")
              inputFile1<-read.table(i)
            }
            cat("Read JunctionBedFiles: \n")
            for(i in getJunctionBedFiles(x)){
              cat(i,"\n")
              inputFile2<-read.table(i,skip=1)
            }
            cat("Read reference annotation...")
            inputFile3<-read.table(getReferenceAnnotation(x))
            cat("Done.\n\n")
            uniqueEnsemble <-unique(inputFile1[1])
            uniqueJunction <-unique(inputFile2[1])
            uniqueReference <-unique(inputFile3[1])
            
            #### calculates the chromosome names that can be used in further calculations
            usedChromosoms <-sort(intersect(uniqueReference$V1,intersect(uniqueEnsemble$V1,uniqueJunction$V1)))
            unusedChromosoms <-sort(setdiff(union(union(uniqueEnsemble$V1,uniqueJunction$V1),uniqueReference$V1),usedChromosoms))
            if(length(usedChromosoms)){
              cat("ExperimentInfo: Only lines with the following chromosome names will be used for the calculations:\n\n",usedChromosoms,"\n\n")
              cat("Unused chromosome names are:\n\n",unusedChromosoms,"\n\nCheck input chromosome names for consistency.\n\n")
              }else{
              stop("ExperimentInfo: No lines are used. Please check input chromosome names for consistency in all inputfiles.")
            }


############################################# End of new check content #######################################################
            cat("Number of input files ok?\n")
            return(t1 & t2)
  
            }
          )
