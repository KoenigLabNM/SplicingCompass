#### extract attribute fields from refFlat_hg18/19.gtf
#### Format example: gene_id "WASH5P"; transcript_id "WASH5P";
getAttributeFieldRefFlat <- function(x, field, attrsep = "; ") {
  s = strsplit(x, split = attrsep, fixed = TRUE)
  res= sapply(s, function(atts) {
    a = strsplit(atts, split = " ", fixed = TRUE)
    m = match(field, sapply(a, "[", 1))
    if (!is.na(m)) {
      rv = a[[m]][2]
    }
    else {
      rv = as.character(NA)
    }
    return(rv)
  })
  res=unlist(lapply(strsplit(res,split="\""),function(el){el[2]}))
}

#### code adapted from https://stat.ethz.ch/pipermail/bioconductor/2008-October/024669.html
getAttributeField <- function(x, field, attrsep=NA, idValSep=NA) {
  if (is.na(attrsep)){
    attrsep = "; "
  }
  if (is.na(idValSep)){
    eof=regexpr(field,x)[1]+nchar(field)
    idValSep=substr(x,eof,eof)
    ##cat(paste("using \"",idValSep,"\" as idValSep\n"))
  }
      
  s = strsplit(x, split = attrsep, fixed = TRUE)
  sapply(s, function(atts) {
    a = strsplit(atts, split = idValSep, fixed = TRUE)
    m = match(field, sapply(a, "[", 1))
    if (!is.na(m)) {
      rv = a[[m]][2]
    }
    else {
      rv = as.character(NA)
    }
    return(rv)
  })
}

## and here is quick parser
gffRead <- function(gffFile, nrows = -1,header=FALSE) {
  ##cat("Reading ", gffFile, ": ", sep="")
  gff = read.table(gffFile, sep="\t", as.is=TRUE, quote="",header=header, comment.char="#", nrows = nrows,
    colClasses=c("character", "character", "character", "integer",
      "integer","character", "character", "character", "character")
    )
  colnames(gff) = c("seqname", "source", "feature", "start", "end", "score", "strand", "frame", "attributes")
  ##cat("found", nrow(gff), "rows with classes:", paste(sapply(gff, class), collapse=", "), "\n")
  stopifnot(!any(is.na(gff$start)), !any(is.na(gff$end)))
  return(gff)
}
## and here is quick parser
gffReadWithCovs <- function(gffFile, nrows = -1) {
  ##cat("Reading ", gffFile, ": ", sep="")
  gff = read.table(gffFile, sep="\t", as.is=TRUE, quote="",header=TRUE, comment.char="#", nrows = nrows)
 # colnames(gff) = c("seqname", "source", "feature", "start", "end", "score", "strand", "frame", "attributes")
  ##cat("found", nrow(gff), "rows with classes:", paste(sapply(gff, class), collapse=", "), "\n")
  stopifnot(!any(is.na(gff$start)), !any(is.na(gff$end)))
  return(gff)
}


